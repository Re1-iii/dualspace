"""PVTv2-B2 encoder with a U-Net decoder for polyp segmentation."""

import torch
import torch.nn as nn
import torch.nn.functional as F
import os

from .pvtv2 import pvt_v2_b2, load_pvtv2_pretrained


class DecoderBlock(nn.Module):
    """UNet Decoder Block"""

    def __init__(self, in_ch, skip_ch, out_ch):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_ch + skip_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )

    def forward(self, x, skip=None):
        x = F.interpolate(x, scale_factor=2, mode="bilinear", align_corners=True)
        if skip is not None:
            if x.shape[2:] != skip.shape[2:]:
                x = F.interpolate(
                    x, size=skip.shape[2:], mode="bilinear", align_corners=True
                )
            x = torch.cat([x, skip], dim=1)
        return self.conv(x)


class PVTv2UNet(nn.Module):
    """PVTv2-B2 Encoder + UNet Decoder

    特征图尺寸 (输入 352x352):
      Stage 1: (B, 64,  88,  88)   stride 4
      Stage 2: (B, 128, 44,  44)   stride 8
      Stage 3: (B, 320, 22,  22)   stride 16
      Stage 4: (B, 512, 11,  11)   stride 32

    Decoder 从 Stage4 逐步上采样, 跟 Stage3/2/1 做 skip connection
    最后上采样到原始分辨率
    """

    def __init__(self, num_classes=1, pretrained_path=None, use_style_in=False):
        """
        Args:
            pretrained_path: pvt_v2_b2.pth 的路径
            use_style_in: 是否在浅层加 InstanceNorm (DG 模式)
        """
        super().__init__()
        self.use_style_in = use_style_in

        # Encoder: PVTv2-B2
        self.encoder = pvt_v2_b2()
        if pretrained_path:
            load_pvtv2_pretrained(self.encoder, pretrained_path)

        # DG: 浅层风格归一化
        # PVTv2 用 LayerNorm 不用 BatchNorm, 所以不能直接替换
        # 改为在 Stage 1 和 Stage 2 输出的特征图上加 InstanceNorm
        if use_style_in:
            self.style_in1 = nn.InstanceNorm2d(64, affine=True)
            self.style_in2 = nn.InstanceNorm2d(128, affine=True)

        # Decoder
        # Stage4(512) → up + cat Stage3(320) → 256
        self.dec4 = DecoderBlock(512, 320, 256)
        # 256 → up + cat Stage2(128) → 128
        self.dec3 = DecoderBlock(256, 128, 128)
        # 128 → up + cat Stage1(64) → 64
        self.dec2 = DecoderBlock(128, 64, 64)
        # 64 → up (no skip) → 32, 到原图尺寸
        self.dec1 = DecoderBlock(64, 0, 32)

        # 输出头
        self.final = nn.Conv2d(32, num_classes, 1)

    def forward(self, x, return_features=False):
        # Encoder: 4 个尺度的特征图
        features = self.encoder(x)  # [s1, s2, s3, s4]
        e1, e2, e3, e4 = features

        # DG: 浅层风格归一化
        if self.use_style_in:
            e1 = self.style_in1(e1)
            e2 = self.style_in2(e2)

        # Decoder
        d4 = self.dec4(e4, e3)  # (B, 256, 22, 22)
        d3 = self.dec3(d4, e2)  # (B, 128, 44, 44)
        d2 = self.dec2(d3, e1)  # (B, 64,  88, 88)
        d1 = self.dec1(d2)  # (B, 32, 176, 176)

        # 上采样到原图尺寸
        out = self.final(d1)  # (B, 1, 176, 176)
        out = F.interpolate(out, size=x.shape[2:], mode="bilinear", align_corners=True)

        if return_features:
            # Optional shallow feature outputs
            return out, [e1, e2]
        return out
