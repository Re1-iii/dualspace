"""Source training and validation datasets with paired image/mask loading."""

import hashlib
from pathlib import Path
import numpy as np
from PIL import Image
import torch
from torch.utils.data import Dataset

EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}
MEAN = torch.tensor([0.485, 0.456, 0.406])[:, None, None]
STD = torch.tensor([0.229, 0.224, 0.225])[:, None, None]


def folder_pair(base):
    base = Path(base)
    images = next((base / p for p in ("image", "images") if (base / p).is_dir()), None)
    masks = next(
        (base / p for p in ("masks", "mask", "GT") if (base / p).is_dir()), None
    )
    if images is None or masks is None:
        raise FileNotFoundError(f"Missing image/mask directory in {base}")
    return images, masks


def index_files(folder):
    result = {}
    for p in sorted(folder.iterdir()):
        if p.is_file() and p.suffix.lower() in EXTS:
            if p.stem in result:
                raise ValueError(f"Duplicate stem: {p.stem}")
            result[p.stem] = p
    return result


class PolypDataset(Dataset):
    def __init__(self, base, size=352, augment=False):
        images, masks = map(index_files, folder_pair(base))
        if not images or images.keys() != masks.keys():
            raise ValueError(f"Empty or mismatched image/mask pairs: {base}")
        self.base = Path(base)
        self.size = size
        self.augment = augment
        self.pairs = [(images[k], masks[k]) for k in sorted(images)]

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, i):
        ip, mp = self.pairs[i]
        with Image.open(ip) as f:
            im = f.convert("RGB")
        with Image.open(mp) as f:
            mask = f.convert("L")
        im = im.resize((self.size, self.size), Image.Resampling.BILINEAR)
        mask = mask.resize((self.size, self.size), Image.Resampling.NEAREST)
        if self.augment:
            if np.random.random() > 0.5:
                im = im.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
                mask = mask.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
            if np.random.random() > 0.5:
                im = im.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
                mask = mask.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
            k = np.random.randint(0, 4)
            if k:
                im = im.rotate(k * 90)
                mask = mask.rotate(k * 90)
        x = torch.from_numpy(np.array(im, dtype=np.float32).transpose(2, 0, 1) / 255)
        y = torch.from_numpy((np.array(mask) > 127.5).astype(np.float32))[None]
        return (x - MEAN) / STD, y, ip.name


def source_datasets(root, size):
    # Kvasir and ClinicDB held-out subsets provide source validation.
    root = Path(root)
    train = PolypDataset(root / "TrainDataset", size, True)
    vals = {
        n: PolypDataset(root / "TestDataset" / n, size)
        for n in ["Kvasir", "CVC-ClinicDB"]
    }
    return train, vals


def manifest(dataset, root):
    return [
        {
            "image": ip.relative_to(root).as_posix(),
            "mask": mp.relative_to(root).as_posix(),
            "image_sha256": hashlib.sha256(ip.read_bytes()).hexdigest(),
            "mask_sha256": hashlib.sha256(mp.read_bytes()).hexdigest(),
        }
        for ip, mp in dataset.pairs
    ]
