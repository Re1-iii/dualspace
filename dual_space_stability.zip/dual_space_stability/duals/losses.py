"""Shared clean anchor and entropy-weighted consistency; sensitive math in FP32."""

import math
import numpy as np
import torch
import torch.nn.functional as F


def dice_bce_loss(logits, target):
    logits, target = logits.float(), target.float()
    p = logits.sigmoid()
    intersection = (p * target).sum((2, 3))
    dice = (2 * intersection + 1) / (p.sum((2, 3)) + target.sum((2, 3)) + 1)
    return 0.5 * F.binary_cross_entropy_with_logits(logits, target) + 0.5 * (
        1 - dice.mean()
    )


def clean_anchor(clean_logits, gated=True):
    p = clean_logits.detach().float().sigmoid()
    q = p.clamp(1e-6, 1 - 1e-6)
    entropy = -(q * q.log() + (1 - q) * (1 - q).log()) / math.log(2)
    c = (1 - entropy).clamp(0, 1) if gated else torch.ones_like(p)
    return p, c


def gated_consistency(student_logits, teacher, confidence, restore=False):
    logits = student_logits.float()
    if restore:
        logits = F.interpolate(
            logits, size=teacher.shape[-2:], mode="bilinear", align_corners=False
        )
    elif logits.shape != teacher.shape:
        raise ValueError("Style and teacher shapes differ")
    # Mean over all pixels, not confidence sum; no hard tau threshold.
    return ((logits.sigmoid() - teacher.detach()) ** 2 * confidence.detach()).mean()


def random_scale_size(
    base_size, scale_min=0.5, scale_max=1.0, multiple=32, min_size=96
):
    if not 0 < scale_min <= scale_max or multiple <= 0:
        raise ValueError("Invalid scale range")
    s = np.random.uniform(scale_min, scale_max)
    return max(int(round(base_size * s / multiple)) * multiple, min_size)
