"""Epoch-level SWAD using raw source-validation loss and BN recalibration.
Internal interval indices ts and te are zero-based."""

import copy
from collections import deque

import torch


class SWAD:
    def __init__(
        self, mode="auto", n_start=3, n_end=6, tol=1.3, tail=20, total_epochs=100
    ):
        assert mode in ("auto", "tail")
        self.mode = mode
        self.n_start = n_start  # optimum patience Ns
        self.n_end = n_end  # overfit patience Ne
        self.tol = tol  # tolerance ratio r
        self.tail = tail
        self.total_epochs = total_epochs

        self.losses = []
        self.snapshots = deque(maxlen=n_start + 1)
        self.avg = None
        self.n_avg = 0
        self.ts = None
        self.te = None
        self.l_ts = None
        self.frozen = False
        self.epoch = -1

    @staticmethod
    def _cpu_state(model):
        return {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}

    def _add(self, state):
        """把一个 state_dict 并入运行平均 (只平均浮点张量; 整型 buffer 取最新)"""
        if self.avg is None:
            self.avg = {}
            for k, v in state.items():
                self.avg[k] = v.clone().float() if v.is_floating_point() else v.clone()
            self.n_avg = 1
        else:
            self.n_avg += 1
            for k in self.avg:
                if self.avg[k].is_floating_point():
                    self.avg[k].add_((state[k].float() - self.avg[k]) / self.n_avg)
                else:
                    self.avg[k] = state[k].clone()

    def update(self, model, val_loss=None):
        self.epoch += 1
        i = self.epoch
        if self.frozen:
            return

        if self.mode == "tail":
            # 简单 SWA: 平均最后 tail 个 epoch
            if i >= self.total_epochs - self.tail:
                self._add(self._cpu_state(model))
            return

        # ---- mode == 'auto': 过拟合感知 SWAD ----
        assert val_loss is not None, "auto 模式每个 epoch 都要传源域 val_loss"
        state = self._cpu_state(model)
        self.snapshots.append(state)
        self.losses.append(float(val_loss))

        if self.ts is None:
            # 起点: l[i-Ns] 是最近 Ns+1 个里的最小 -> 该点是稳定最优
            if i >= self.n_start:
                window = self.losses[i - self.n_start : i + 1]
                if self.losses[i - self.n_start] == min(window):
                    self.ts = i - self.n_start
                    self.l_ts = self.losses[self.ts]
                    for s in self.snapshots:  # deque 恰是 epoch ts..i
                        self._add(s)
        elif self.te is None:
            self._add(state)  # 当前 epoch 纳入平均
            # 终点: 最近 Ne 个 val loss 全部 > tol * l_ts -> 已离开平坦区(过拟合)
            if i >= self.ts + self.n_end:
                recent = self.losses[i - self.n_end + 1 : i + 1]
                if min(recent) > self.tol * self.l_ts:
                    self.te = i
                    self.frozen = True

    def has_avg(self):
        return self.avg is not None

    def finalize_into(self, model):
        """把平均权重写进 model 的深拷贝并返回 (BN 统计仍需 update_bn 重算)。
        若 auto 没攒到平坦区, 用 deque 里最后几个快照兜底。"""
        if self.avg is None:
            if len(self.snapshots) == 0:
                return None
            for s in self.snapshots:
                self._add(s)
        swad_model = copy.deepcopy(model)
        tgt = swad_model.state_dict()
        for k in tgt:
            tgt[k].copy_(self.avg[k].to(tgt[k].device, tgt[k].dtype))
        return swad_model

    def info(self):
        return {
            "mode": self.mode,
            "ts": self.ts,
            "te": self.te,
            "n_avg": self.n_avg,
            "frozen": self.frozen,
            "n_val": len(self.losses),
        }

    def state_dict(self):
        """序列化 SWAD 状态 (断点续训用)。ts 确定后 snapshots 已无用, 不再存以省空间。"""
        return {
            "mode": self.mode,
            "n_start": self.n_start,
            "n_end": self.n_end,
            "tol": self.tol,
            "tail": self.tail,
            "total_epochs": self.total_epochs,
            "losses": list(self.losses),
            "snapshots": list(self.snapshots) if self.ts is None else [],
            "avg": self.avg,
            "n_avg": self.n_avg,
            "ts": self.ts,
            "te": self.te,
            "l_ts": self.l_ts,
            "frozen": self.frozen,
            "epoch": self.epoch,
        }

    def load_state_dict(self, sd):
        self.mode = sd["mode"]
        self.n_start = sd["n_start"]
        self.n_end = sd["n_end"]
        self.tol = sd["tol"]
        self.tail = sd["tail"]
        self.total_epochs = sd["total_epochs"]
        self.losses = list(sd["losses"])
        self.snapshots = deque(sd["snapshots"], maxlen=self.n_start + 1)
        self.avg = sd["avg"]
        self.n_avg = sd["n_avg"]
        self.ts = sd["ts"]
        self.te = sd["te"]
        self.l_ts = sd["l_ts"]
        self.frozen = sd["frozen"]
        self.epoch = sd["epoch"]


@torch.no_grad()
def update_bn(loader, model, device, max_batches=None):
    """重算 BN running mean/var (SWAD/SWA 平均后必须做)。
    momentum=None -> 累积移动平均, 等价于在这批数据上重新统计。"""
    momenta = {}
    for m in model.modules():
        if isinstance(m, torch.nn.modules.batchnorm._BatchNorm):
            m.reset_running_stats()
            momenta[m] = m.momentum
            m.momentum = None
    if not momenta:
        return  # 无 BN (如纯 LayerNorm), 无需重算

    was_training = model.training
    model.train()
    n = 0
    for batch in loader:
        imgs = batch[0].to(device)
        model(imgs)
        n += 1
        if max_batches is not None and n >= max_batches:
            break
    for m, mom in momenta.items():
        m.momentum = mom
    if not was_training:
        model.eval()


# =========================================================================
# 自测
# =========================================================================
