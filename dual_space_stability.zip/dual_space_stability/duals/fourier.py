"""Low-frequency donor-amplitude replacement on ImageNet-normalized inputs."""

import math
import numpy as np
import torch


def low_frequency_slices(height, width, beta=0.05):
    if not math.isfinite(beta) or not 0 <= beta < 0.5:
        raise ValueError("beta must be finite and in [0,0.5)")
    rh, rw = max(math.floor(beta * height), 1), max(math.floor(beta * width), 1)
    cy, cx = height // 2, width // 2
    if cy - rh < 0 or cx - rw < 0 or cy + rh >= height or cx + rw >= width:
        raise ValueError("Image too small for the centered odd-width window")
    return slice(cy - rh, cy + rh + 1), slice(cx - rw, cx + rw + 1)


def fourier_style_swap(source, donor, alpha=1.0, ratio=0.05):
    """CHW or BCHW tensors; donor amplitude and source phase reconstruction.
    FFT runs in float32 outside AMP (float64 inputs stay float64). No clipping.
    """
    if source.shape != donor.shape or source.ndim not in (3, 4):
        raise ValueError("Expected same CHW or BCHW shape")
    if not source.is_floating_point() or not donor.is_floating_point():
        raise TypeError("Expected real floating-point inputs")
    if source.device != donor.device:
        raise ValueError("Devices differ")
    if not math.isfinite(alpha) or not 0 <= alpha <= 1:
        raise ValueError("alpha must be finite and in [0,1]")
    sy, sx = low_frequency_slices(*source.shape[-2:], ratio)
    if alpha == 0:
        return source.clone()
    dtype = torch.float64 if source.dtype == torch.float64 else torch.float32
    with torch.autocast(source.device.type, enabled=False):
        fs = torch.fft.fftshift(torch.fft.fft2(source.to(dtype)), dim=(-2, -1))
        fd = torch.fft.fftshift(torch.fft.fft2(donor.to(dtype)), dim=(-2, -1))
        amp = fs.abs().clone()
        amp[..., sy, sx] = (1 - alpha) * amp[..., sy, sx] + alpha * fd.abs()[
            ..., sy, sx
        ]
        spectrum = amp * torch.exp(1j * torch.angle(fs))
        out = torch.fft.ifft2(torch.fft.ifftshift(spectrum, dim=(-2, -1))).real
    return out.to(source.dtype)


class FourierAmplitudeSwap:
    """Per-image Bernoulli selection; independent uniform donor j != i.
    Donors are sampled uniformly by rejecting self-indices for B>1.
    B=1 returns a copy. All donors come from the original, unmodified batch.
    """

    def __init__(self, prob=0.7, alpha=1.0, beta=0.05):
        if not math.isfinite(prob) or not 0 <= prob <= 1:
            raise ValueError("prob must lie in [0,1]")
        if not math.isfinite(alpha) or not 0 <= alpha <= 1:
            raise ValueError("alpha must lie in [0,1]")
        low_frequency_slices(352, 352, beta)
        self.prob, self.alpha, self.beta = prob, alpha, beta

    @torch.no_grad()
    def __call__(self, images, return_info=False):
        if images.ndim != 4 or not images.is_floating_point():
            raise ValueError("Expected floating BCHW input")
        n = len(images)
        out = images.clone()
        donors = [-1] * n
        if n > 1 and self.prob > 0 and self.alpha > 0:
            for i in range(n):
                if np.random.random() > self.prob:
                    continue
                j = np.random.randint(0, n)
                while j == i:
                    j = np.random.randint(0, n)
                donors[i] = int(j)
                out[i] = fourier_style_swap(images[i], images[j], self.alpha, self.beta)
        return (out, {"donor_indices": donors}) if return_info else out
