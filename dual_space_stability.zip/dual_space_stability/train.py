"""Train PVTv2-UNet with Fourier and scale consistency and SWAD."""

import argparse
import json
import random
import os
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from duals.model import PVTv2UNet
from duals.fourier import FourierAmplitudeSwap
from duals.losses import (
    dice_bce_loss,
    clean_anchor,
    gated_consistency,
    random_scale_size,
)
from duals.data import source_datasets, manifest
from duals.swad import SWAD, update_bn


def atomic_save(path, obj):
    tmp = path.with_suffix(".tmp")
    torch.save(obj, tmp)
    os.replace(tmp, path)


def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def rng_state():
    return {
        "python": random.getstate(),
        "numpy": np.random.get_state(),
        "torch": torch.get_rng_state(),
        "cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,
    }


def restore_rng(state):
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"])
    if torch.cuda.is_available() and state["cuda"] is not None:
        torch.cuda.set_rng_state_all(state["cuda"])


def train_step(model, optimizer, scaler, x, y, c, augmentor, device):
    optimizer.zero_grad(set_to_none=True)
    xa = augmentor(x) if c["use_style"] else None
    with torch.autocast(device.type, enabled=device.type == "cuda"):
        z = model(x)
        za = model(xa) if xa is not None else None
    seg = dice_bce_loss(z, y)
    teacher, conf = clean_anchor(z, c["use_gate"])
    sty = gated_consistency(za, teacher, conf) if za is not None else seg.new_zeros(())
    main_loss = seg + c["style_weight"] * sty
    scaler.scale(main_loss).backward()
    scale_value = 0.0
    # Sequential backward frees the style graph and accumulates scale gradients.
    if c["use_scale"]:
        size = random_scale_size(c["image_size"], c["scale_min"], c["scale_max"])
        xs = F.interpolate(x, size=(size, size), mode="bilinear", align_corners=False)
        with torch.autocast(device.type, enabled=device.type == "cuda"):
            zs = model(xs)
        scale_loss = c["scale_weight"] * gated_consistency(
            zs, teacher, conf, restore=True
        )
        scaler.scale(scale_loss).backward()
        scale_value = scale_loss.item()
    scaler.unscale_(optimizer)
    torch.nn.utils.clip_grad_norm_(model.parameters(), c["grad_clip"])
    scaler.step(optimizer)
    scaler.update()
    return {
        "loss": main_loss.item() + scale_value,
        "seg": seg.item(),
        "style": sty.item(),
        "weighted_scale": scale_value,
    }


@torch.no_grad()
def validate(model, loaders, device):
    model.eval()
    total = 0.0
    n = 0
    for loader in loaders.values():
        for x, y, _ in loader:
            x, y = x.to(device), y.to(device)
            with torch.autocast(device.type, enabled=device.type == "cuda"):
                z = model(x)
            total += dice_bce_loss(z, y).item() * len(x)
            n += len(x)
    if n == 0:
        raise RuntimeError("No source validation samples")
    return total / n


def run(
    c,
    root,
    out,
    pretrained,
    device,
    resume=False,
    from_scratch=False,
    stop_after=None,
    preflight=False,
):
    seed_all(c["seed"])
    out.mkdir(parents=True, exist_ok=True)
    train, vals = source_datasets(root, c["image_size"])
    if len(train) < c["batch_size"]:
        raise ValueError("Training dataset smaller than batch size")
    roles = {
        "source_train": manifest(train, root),
        **{n: manifest(ds, root) for n, ds in vals.items()},
    }
    train_hashes = {r["image_sha256"] for r in roles["source_train"]}
    for n in vals:
        if train_hashes & {r["image_sha256"] for r in roles[n]}:
            raise ValueError(
                f"Identical image bytes appear in source train and validation: {n}"
            )
    manifest_file = out / "data_manifest.json"
    ckpath = out / "resume.pth"
    if resume:
        if not ckpath.exists():
            raise FileNotFoundError(ckpath)
        if not manifest_file.exists() or json.loads(manifest_file.read_text()) != roles:
            raise ValueError(
                "Dataset manifest changed or missing; use a new output directory"
            )
    else:
        if ckpath.exists():
            raise FileExistsError("Run exists; use --resume or a new output directory")
        manifest_file.write_text(json.dumps(roles, indent=2), encoding="utf-8")
    dl = DataLoader(
        train, batch_size=c["batch_size"], shuffle=True, num_workers=0, drop_last=True
    )
    vl = {
        n: DataLoader(ds, batch_size=1, shuffle=False, num_workers=0)
        for n, ds in vals.items()
    }
    if (
        not resume
        and not from_scratch
        and (pretrained is None or not pretrained.is_file())
    ):
        raise FileNotFoundError(
            "Provide --pretrained pvt_v2_b2.pth; scratch training requires --from-scratch"
        )
    model = PVTv2UNet(
        pretrained_path=str(pretrained) if pretrained and not resume else None,
        use_style_in=False,
    ).to(device)
    aug = FourierAmplitudeSwap(c["fourier_prob"], c["fourier_alpha"], c["fourier_beta"])
    opt = torch.optim.AdamW(
        model.parameters(), lr=c["lr"], weight_decay=c["weight_decay"]
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        opt, T_max=c["epochs"], eta_min=c["eta_min"]
    )
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    sw = (
        SWAD(
            n_start=c["swad_n_start"],
            n_end=c["swad_n_end"],
            tol=c["swad_tol"],
            total_epochs=c["epochs"],
        )
        if c["use_swad"]
        else None
    )
    start = 0
    history = []
    if resume:
        # Only load locally produced, trusted full training states.
        ck = torch.load(ckpath, map_location="cpu", weights_only=False)
        if ck["config"] != c:
            raise ValueError("Resume config differs from saved configuration")
        model.load_state_dict(ck["model"], strict=True)
        opt.load_state_dict(ck["optimizer"])
        scheduler.load_state_dict(ck["scheduler"])
        scaler.load_state_dict(ck["scaler"])
        if sw is not None:
            sw.load_state_dict(ck["swad"])
        start = ck["epoch"]
        history = ck["history"]
        restore_rng(ck["rng"])
    if preflight:
        x, y, _ = next(iter(dl))
        model.train()
        info = train_step(
            model, opt, scaler, x.to(device), y.to(device), c, aug, device
        )
        if not all(np.isfinite(v) for v in info.values()):
            raise RuntimeError("Non-finite preflight loss")
        print("Preflight forward/backward passed:", info, flush=True)
        print("Preflight complete; no checkpoint saved.")
        return
    (out / "config.json").write_text(json.dumps(c, indent=2), encoding="utf-8")
    for epoch in range(start, c["epochs"]):
        model.train()
        stats = []
        for i, (x, y, _) in enumerate(dl, 1):
            stats.append(
                train_step(
                    model, opt, scaler, x.to(device), y.to(device), c, aug, device
                )
            )
            if i % 50 == 0:
                print(
                    f'Epoch {epoch+1} batch {i}/{len(dl)} loss={stats[-1]["loss"]:.5f}',
                    flush=True,
                )
        scheduler.step()
        val = validate(model, vl, device)
        if sw is not None:
            sw.update(model, val)
        row = {
            "epoch": epoch + 1,
            "source_val_loss": val,
            **{k: float(np.mean([r[k] for r in stats])) for k in stats[0]},
        }
        history.append(row)
        state = {
            "epoch": epoch + 1,
            "model": model.state_dict(),
            "optimizer": opt.state_dict(),
            "scheduler": scheduler.state_dict(),
            "scaler": scaler.state_dict(),
            "rng": rng_state(),
            "config": c,
            "history": history,
            "swad": sw.state_dict() if sw is not None else None,
        }
        atomic_save(ckpath, state)
        (out / "history.json").write_text(
            json.dumps(history, indent=2), encoding="utf-8"
        )
        print(row, flush=True)
        if stop_after and epoch + 1 >= stop_after and epoch + 1 < c["epochs"]:
            print("Stopped at epoch boundary; use --resume to continue.")
            return
    atomic_save(
        out / "last.pth",
        {"model": model.state_dict(), "config": c, "epoch": c["epochs"]},
    )
    if sw is not None:
        averaged = sw.finalize_into(model)
        if averaged is None:
            raise RuntimeError("No SWAD state available")
        update_bn(dl, averaged, device, max_batches=c["bn_batches"])
        atomic_save(
            out / "swad.pth",
            {"model": averaged.state_dict(), "config": c, "swad_info": sw.info()},
        )
        (out / "swad_info.json").write_text(
            json.dumps(sw.info(), indent=2), encoding="utf-8"
        )
    print("Training complete.")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument(
        "--config", type=Path, default=Path(__file__).parent / "configs/pvtb2.json"
    )
    p.add_argument("--data-root", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--pretrained", type=Path)
    p.add_argument("--from-scratch", action="store_true")
    p.add_argument("--resume", action="store_true")
    p.add_argument("--preflight", action="store_true")
    p.add_argument("--stop-after", type=int)
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    a = p.parse_args()
    c = json.loads(a.config.read_text())
    run(
        c,
        a.data_root.resolve(),
        a.output,
        a.pretrained,
        torch.device(a.device),
        a.resume,
        a.from_scratch,
        a.stop_after,
        a.preflight,
    )


if __name__ == "__main__":
    main()
