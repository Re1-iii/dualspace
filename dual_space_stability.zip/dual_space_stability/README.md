# Dual-Space Stability

Training components for cross-dataset polyp segmentation with PVTv2-B2 + U-Net.

## Components

| File | Function |
|---|---|
| `duals/fourier.py` | Low-frequency donor-amplitude replacement |
| `duals/losses.py` | Dice+BCE supervision, shared entropy weights, appearance and scale consistency |
| `duals/swad.py` | Epoch-level weight averaging and BN recalibration |
| `duals/model.py`, `duals/pvtv2.py` | PVTv2-B2 encoder and U-Net decoder |
| `duals/data.py` | Image/mask loading and source-domain data handling |
| `train.py` | Training entry point |
| `configs/pvtb2.json` | Training configuration |

## Installation

Use Python 3.10–3.12 and install the PyTorch build appropriate for your device.

```bash
python -m pip install -r requirements.txt
```

## Data

Under the data root, prepare the following folders, each containing `images/` and `masks/` with matching filename stems:

| Folder | Role |
|---|---|
| `TrainDataset` | Source training |
| `TestDataset/Kvasir` | Source validation |
| `TestDataset/CVC-ClinicDB` | Source validation |

## Training

Place the PVTv2-B2 pretrained encoder weights at `pretrained/pvt_v2_b2.pth`, then run:

```bash
python train.py --data-root "data" --output "runs/full_seed42" --pretrained "pretrained/pvt_v2_b2.pth"
```

To use a custom configuration or resume training:

```bash
python train.py --config "configs/pvtb2.json" --data-root "data" --output "runs/full_seed42" --resume
```

The output folder contains configuration, data manifest, training history, resume state, `last.pth`, and `swad.pth`. Resume using the same configuration and data. Use `--device cpu` to select CPU execution.

## Fourier settings

Defaults: `p=0.7`, `alpha=1.0`, `beta=0.05`. For each selected image, another image in the batch supplies the low-frequency amplitude. A 352×352 input uses a centered 35×35 frequency window. Source amplitude outside the window and source phase are retained. FFT operates on ImageNet-normalized inputs; inverse-FFT outputs are used without clipping or additional normalization. A single-image batch is returned unchanged.

Both consistency branches use the detached clean prediction and its entropy-derived weights. Scale logits are restored to the clean resolution before sigmoid. SWAD uses epoch-end weights and source-validation loss, followed by BN recalibration on source training batches.

## Acknowledgements

The encoder implementation is based on [PVT](https://github.com/whai362/PVT). The training framework builds on Fourier amplitude augmentation and SWAD weight averaging.
